# subtitle.ifim — AI subtitle translator for Emby

[![Build](../../actions/workflows/build.yml/badge.svg)](../../actions/workflows/build.yml)

An Emby Server plugin that adds a subtitle source called **subtitle.ifim**.
When Emby needs a subtitle in a language a video doesn't have, the plugin takes a text subtitle the video
already has, translates it with [subtitle.ifim.shop](https://subtitle.ifim.shop) and hands it back to Emby,
which saves it next to the video (e.g. `Movie.vi.srt`).

Because it translates the video's own subtitle, the timing always matches.

> **Status: beta.** Feedback welcome in the [Emby forum thread](#) or [GitHub issues](../../issues).

![thumbnail](src/Emby.SubtitleIfim/thumb.png)

## Features

- Plugs into Emby's normal subtitle flow: automatic download for new media, the
  *Download missing subtitles* scheduled task, or a manual search in *Edit subtitles*
- 20+ target languages: Vietnamese, English, Chinese (Simplified / Traditional), Japanese, Korean, Thai,
  Indonesian, Malay, Filipino, Hindi, Arabic, Turkish, Russian, Spanish, Portuguese, French, German, Italian,
  Dutch, Polish
- Source can be an external `.srt` / `.ass` / `.vtt` file or an embedded text track (MKV); Emby converts it to SRT
- Handles legacy encodings (Windows-1252, GBK, Big5…)
- Optional bilingual output (original line + translation)
- Translates one file at a time, so a full library scan won't flood the server

## Requirements

- Emby Server **4.8** or newer
- A free API key from <https://subtitle.ifim.shop/account/api>
  (the free plan includes a daily character allowance; text that has been translated before is returned
  instantly and doesn't count)

## Installation

1. Download `Emby.SubtitleIfim.dll` from the [latest release](../../releases/latest).
2. Copy it into Emby's `plugins` folder:

   | Platform | Folder |
   |---|---|
   | Windows | `%AppData%\Emby-Server\programdata\plugins` |
   | Linux | `/var/lib/emby/plugins` |
   | Docker | `/config/plugins` |

3. Restart Emby Server.
4. **Dashboard → Plugins → subtitle.ifim**: paste your API key, click **Test API key**, then **Save**.
5. **Library → edit a library → Subtitle downloads**: tick **subtitle.ifim** and the languages you want.
   New media gets translated subtitles automatically. For existing media run
   **Scheduled Tasks → Download missing subtitles**, or open a movie/episode → **Edit subtitles** → search.

## Settings

| Setting | Meaning |
|---|---|
| API key | Your key from subtitle.ifim.shop |
| Server URL | Leave as `https://subtitle.ifim.shop` |
| Preferred source subtitle | Which language to translate *from* when a video has several |
| Translation quality | *Standard* (free daily allowance) or *Expert* (uses your account's Expert quota) |
| Chinese variant | Simplified or Traditional when Emby just asks for "Chinese" |
| Bilingual | Keep the original line and add the translation under it |
| Give up after | Maximum minutes to wait for one translation |

The target language is not set here: the plugin translates into whatever language Emby asks for.

## Privacy

To translate, the plugin sends **the subtitle text and the video title** (e.g. `Movie Name (2020)` or
`Show S01E02`) to the configured server. No video or audio files, library data or viewing history are sent.

## Limitations

- Image-based subtitles (PGS / VobSub) can't be translated (they need OCR first).
- A video with no subtitle at all gets no result.
- Results are machine translations: good, but not equal to a human translation.

## Building from source

Requires the [.NET SDK](https://dotnet.microsoft.com/download) (6.0 or newer).

```bash
dotnet build src/Emby.SubtitleIfim/Emby.SubtitleIfim.csproj -c Release
# output: src/Emby.SubtitleIfim/bin/Release/netstandard2.0/Emby.SubtitleIfim.dll
```

Every push is built by GitHub Actions. Pushing a tag like `v1.0.1` builds that version and attaches the
DLL to a GitHub release.

### Project layout

| File | Purpose |
|---|---|
| `Plugin.cs` | Plugin entry point: name, GUID, config page, thumbnail |
| `IfimSubtitleProvider.cs` | `ISubtitleProvider`: `Search` lists translatable source subtitles, `GetSubtitles` converts the source to SRT, translates it and returns the result |
| `IfimApiClient.cs` | Calls the `/api/v1` API: upload, poll every 3 s, download; waits and retries on HTTP 429 |
| `Languages.cs` | Emby language codes (ISO 639-1/2) ↔ site language codes |
| `Configuration/` | Dashboard settings page |

## License

[MIT](LICENSE)
