# Emby.SubtitleIfim — plugin Emby dịch phụ đề tự động

*English: see [README.md](../README.md).*

Plugin thêm nguồn phụ đề **subtitle.ifim** vào Emby Server (4.8+). Khi Emby cần phụ đề ngôn ngữ X mà phim chưa có,
plugin lấy một phụ đề dạng chữ sẵn có của phim (file `.srt/.ass/.vtt` đi kèm hoặc track nhúng trong MKV), gửi lên
`subtitle.ifim.shop/api/v1/translate` để dịch sang X, rồi trả về cho Emby lưu cạnh file phim (vd. `Movie.vi.srt`).

## Build

```
dotnet build src/Emby.SubtitleIfim/Emby.SubtitleIfim.csproj -c Release
# => src/Emby.SubtitleIfim/bin/Release/netstandard2.0/Emby.SubtitleIfim.dll
```

Hoặc tải DLL đã build sẵn ở mục Releases của repo (GitHub Actions tự build khi push tag `v*`).

## Cài & dùng

1. Chép `Emby.SubtitleIfim.dll` vào thư mục `plugins` của Emby Server
   (Windows: `%AppData%\Emby-Server\programdata\plugins`, Linux: `/var/lib/emby/plugins`, Docker: `/config/plugins`), restart Emby.
2. Tạo API key ở https://subtitle.ifim.shop/account/api.
3. Emby → Settings → Plugins → **subtitle.ifim**: dán key, bấm *Test API key*, *Save*.
4. Library → sửa thư viện → **Subtitle downloads**: tick *subtitle.ifim* và ngôn ngữ muốn có.
   Phim mới tự có phụ đề dịch; phim cũ: Scheduled Tasks → *Download missing subtitles*.
   Hoặc mở phim → *Edit subtitles* → tìm → chọn kết quả của subtitle.ifim.

## Cấu trúc

| File (trong `src/Emby.SubtitleIfim/`) | Vai trò |
|---|---|
| `IfimSubtitleProvider.cs` | `ISubtitleProvider`: `Search` liệt kê phụ đề nguồn có thể dịch, `GetSubtitles` chuyển nguồn sang SRT (qua `ISubtitleEncoder` của Emby), dịch, trả kết quả. Mỗi lúc chỉ dịch 1 file. |
| `IfimApiClient.cs` | Gọi API: gửi file, chờ (poll 3s), tải bản dịch; server báo bận (429 + `retry_after`) thì chờ rồi gửi lại. |
| `Languages.cs` | Mã ngôn ngữ Emby (ISO 639-1/2) ↔ mã của site. |
| `Configuration/` | Trang cấu hình trong Emby dashboard. |

## Giới hạn

- Phụ đề dạng ảnh (PGS/VobSub) không dịch được — cần OCR trước.
- Phim không có phụ đề nào thì plugin không trả kết quả.
- Server: `API_DAILY_CHARS` (mặc định 300.000 ký tự / tài khoản / 24h, bản Standard), `API_MAX_RUNNING` (2 file cùng lúc).
  Nội dung đã từng dịch được trả lại ngay, không tính vào hạn mức.

## Quyền riêng tư

Để dịch, plugin gửi **nội dung phụ đề và tên phim** (vd. `Tên phim (2020)` hoặc `Tên series S01E02`) lên server đã cấu hình. Không gửi file video/âm thanh, dữ liệu thư viện hay lịch sử xem.
