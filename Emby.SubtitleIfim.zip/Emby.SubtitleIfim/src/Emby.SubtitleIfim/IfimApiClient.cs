using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediaBrowser.Model.Logging;
using MediaBrowser.Model.Serialization;

namespace Emby.SubtitleIfim
{
    /// <summary>Gọi API /api/v1 của subtitle.ifim.shop: gửi phụ đề, chờ dịch xong, tải bản dịch.</summary>
    public class IfimApiClient
    {
        private static readonly HttpClient Http = CreateHttp();

        private readonly IJsonSerializer _json;
        private readonly ILogger _logger;

        public IfimApiClient(IJsonSerializer json, ILogger logger)
        {
            _json = json;
            _logger = logger;
        }

        private static HttpClient CreateHttp()
        {
            var http = new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("Emby.SubtitleIfim/" + typeof(IfimApiClient).Assembly.GetName().Version);
            return http;
        }

        // Tên thuộc tính trùng khoá JSON của server
        private class TaskDto
        {
            public string task_id { get; set; }
            public string status { get; set; }
            public int progress { get; set; }
            public string error { get; set; }
            public bool cached { get; set; }
            public int? retry_after { get; set; }
        }

        /// <summary>Dịch nội dung SRT sang destLang, trả về nội dung SRT đã dịch.</summary>
        public async Task<string> TranslateAsync(PluginConfiguration config, string srt, string fileName, string destLang,
            string title, CancellationToken cancellationToken)
        {
            var deadline = DateTime.UtcNow.AddMinutes(Math.Max(1, config.TimeoutMinutes));
            var baseUrl = (config.ServerUrl ?? "").Trim().TrimEnd('/');
            if (string.IsNullOrEmpty(baseUrl))
                baseUrl = "https://subtitle.ifim.shop";

            TaskDto task;
            while (true)
            {
                var form = new MultipartFormDataContent
                {
                    { new StringContent(destLang), "dest_lang" },
                    { new StringContent(config.Bilingual ? "1" : "0"), "bilingual" },
                    { new StringContent(config.Engine == "expert" ? "expert" : "google"), "engine" },
                    { new StringContent(title ?? ""), "title" }
                };
                var file = new ByteArrayContent(Encoding.UTF8.GetBytes(srt));
                file.Headers.ContentType = new MediaTypeHeaderValue("text/plain") { CharSet = "utf-8" };
                form.Add(file, "file", fileName);

                var (status, body) = await SendAsync(HttpMethod.Post, baseUrl + "/api/v1/translate", config.ApiKey, form,
                    cancellationToken).ConfigureAwait(false);
                task = Parse(body);
                // Đang dịch quá nhiều file cùng lúc => chờ rồi gửi lại
                if (status == (HttpStatusCode)429 && task?.retry_after != null && DateTime.UtcNow < deadline)
                {
                    _logger.Info("subtitle.ifim: server busy, retrying in {0}s", task.retry_after);
                    await Task.Delay(TimeSpan.FromSeconds(task.retry_after.Value), cancellationToken).ConfigureAwait(false);
                    continue;
                }
                if ((int)status >= 400 || task?.task_id == null)
                    throw new Exception("subtitle.ifim: " + (task?.error ?? $"HTTP {(int)status}"));
                break;
            }

            _logger.Info("subtitle.ifim: translating {0} to {1} (task {2}{3})", fileName, destLang, task.task_id,
                task.cached ? ", cached" : "");

            var taskId = task.task_id;
            while (task.status != "completed")
            {
                if (task.status == "error")
                    throw new Exception("subtitle.ifim: " + (task.error ?? "translation failed"));
                if (DateTime.UtcNow > deadline)
                    throw new TimeoutException($"subtitle.ifim: translation took longer than {config.TimeoutMinutes} minutes");
                await Task.Delay(TimeSpan.FromSeconds(3), cancellationToken).ConfigureAwait(false);

                HttpStatusCode status;
                string body;
                try
                {
                    (status, body) = await SendAsync(HttpMethod.Get, baseUrl + "/api/v1/tasks/" + taskId, config.ApiKey,
                        null, cancellationToken).ConfigureAwait(false);
                }
                catch (Exception ex) when (!cancellationToken.IsCancellationRequested &&
                                           (ex is HttpRequestException || ex is TaskCanceledException))
                {
                    // Rớt mạng / timeout tạm thời => thử lại lần sau, không bỏ cả bản dịch
                    _logger.Debug("subtitle.ifim: polling task {0} failed ({1}), retrying", taskId, ex.Message);
                    continue;
                }

                if ((int)status >= 500)
                    continue;  // lỗi tạm thời của server => thử lại lần sau
                if ((int)status >= 400)  // key bị thu hồi, task bị xoá... => dừng ngay, không poll tới hết thời gian chờ
                    throw new Exception("subtitle.ifim: " + (Parse(body)?.error ?? $"HTTP {(int)status}"));
                task = Parse(body) ?? throw new Exception($"subtitle.ifim: HTTP {(int)status}");
            }

            var (fileStatus, content) = await SendAsync(HttpMethod.Get, baseUrl + "/api/v1/tasks/" + taskId + "/file",
                config.ApiKey, null, cancellationToken).ConfigureAwait(false);
            if (fileStatus != HttpStatusCode.OK)
                throw new Exception("subtitle.ifim: " + (Parse(content)?.error ?? $"download failed (HTTP {(int)fileStatus})"));
            return content;
        }

        private TaskDto Parse(string body)
        {
            try
            {
                return string.IsNullOrWhiteSpace(body) ? null : _json.DeserializeFromString<TaskDto>(body);
            }
            catch
            {
                return null;
            }
        }

        private static async Task<(HttpStatusCode, string)> SendAsync(HttpMethod method, string url, string apiKey,
            HttpContent content, CancellationToken cancellationToken)
        {
            using (var request = new HttpRequestMessage(method, url) { Content = content })
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", (apiKey ?? "").Trim());
                using (var response = await Http.SendAsync(request, cancellationToken).ConfigureAwait(false))
                {
                    var bytes = await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);
                    return (response.StatusCode, Encoding.UTF8.GetString(bytes));
                }
            }
        }
    }
}
