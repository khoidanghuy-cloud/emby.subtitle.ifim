define(['baseView', 'loading', 'emby-input', 'emby-button', 'emby-select', 'emby-checkbox'], function (BaseView, loading) {
    'use strict';

    var pluginId = '7c2f1b3e-5a8d-4e61-9b0c-3d4e5f6a7b81';

    function serverUrl(view) {
        return (view.querySelector('#txtServerUrl').value || 'https://subtitle.ifim.shop').replace(/\/+$/, '');
    }

    function View(view, params) {
        BaseView.apply(this, arguments);

        view.querySelector('form').addEventListener('submit', function (e) {
            e.preventDefault();
            loading.show();
            ApiClient.getPluginConfiguration(pluginId).then(function (config) {
                config.ApiKey = view.querySelector('#txtApiKey').value.trim();
                config.ServerUrl = serverUrl(view);
                config.SourceLanguage = view.querySelector('#selSourceLanguage').value;
                config.Engine = view.querySelector('#selEngine').value;
                config.ChineseVariant = view.querySelector('#selChineseVariant').value;
                config.Bilingual = view.querySelector('#chkBilingual').checked;
                config.TimeoutMinutes = parseInt(view.querySelector('#txtTimeout').value, 10) || 20;
                ApiClient.updatePluginConfiguration(pluginId, config).then(Dashboard.processPluginConfigurationUpdateResult);
            });
            return false;
        });

        // Gọi thẳng /api/v1/me từ trình duyệt (server bật CORS cho đường này)
        view.querySelector('.btnTest').addEventListener('click', function () {
            var out = view.querySelector('.testResult');
            out.textContent = 'Checking...';
            fetch(serverUrl(view) + '/api/v1/me', {
                headers: { 'Authorization': 'Bearer ' + view.querySelector('#txtApiKey').value.trim() }
            }).then(function (r) {
                return r.json().then(function (d) { return { ok: r.ok, d: d }; });
            }).then(function (res) {
                if (!res.ok) { out.textContent = '❌ ' + (res.d.error || 'Invalid key'); return; }
                var u = res.d.usage;
                out.textContent = '✅ Connected as ' + (res.d.account.name || ('account #' + res.d.account.id)) +
                    ' · ' + u.left_chars_24h.toLocaleString() + ' / ' + u.daily_chars.toLocaleString() +
                    ' characters left today · ' + res.d.idollar + ' iDollar';
            }).catch(function (err) {
                out.textContent = '❌ Cannot reach ' + serverUrl(view) + ' (' + err.message + ')';
            });
        });
    }

    Object.assign(View.prototype, BaseView.prototype);

    View.prototype.onResume = function (options) {
        BaseView.prototype.onResume.apply(this, arguments);
        var view = this.view;
        loading.show();
        ApiClient.getPluginConfiguration(pluginId).then(function (config) {
            view.querySelector('#txtApiKey').value = config.ApiKey || '';
            view.querySelector('#txtServerUrl').value = config.ServerUrl || 'https://subtitle.ifim.shop';
            view.querySelector('#selSourceLanguage').value = config.SourceLanguage || 'eng';
            view.querySelector('#selEngine').value = config.Engine || 'google';
            view.querySelector('#selChineseVariant').value = config.ChineseVariant || 'zh-cn';
            view.querySelector('#chkBilingual').checked = !!config.Bilingual;
            view.querySelector('#txtTimeout').value = config.TimeoutMinutes || 20;
            loading.hide();
        });
    };

    return View;
});
