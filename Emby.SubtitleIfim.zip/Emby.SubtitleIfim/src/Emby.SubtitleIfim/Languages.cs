using System;
using System.Collections.Generic;
using System.Linq;

namespace Emby.SubtitleIfim
{
    /// <summary>Mã ngôn ngữ của Emby (ISO 639-1/639-2) &lt;-&gt; mã ngôn ngữ của subtitle.ifim.shop.</summary>
    public static class Languages
    {
        private static readonly Dictionary<string, string> Map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["vi"] = "vi", ["vie"] = "vi",
            ["en"] = "en", ["eng"] = "en",
            ["id"] = "id", ["ind"] = "id",
            ["ms"] = "ms", ["msa"] = "ms", ["may"] = "ms",
            ["th"] = "th", ["tha"] = "th",
            ["zh-cn"] = "zh-cn", ["zh-hans"] = "zh-cn", ["chs"] = "zh-cn",
            ["zh-tw"] = "zh-tw", ["zh-hk"] = "zh-tw", ["zh-hant"] = "zh-tw", ["cht"] = "zh-tw",
            ["ko"] = "ko", ["kor"] = "ko",
            ["ja"] = "ja", ["jpn"] = "ja",
            ["tl"] = "tl", ["fil"] = "tl", ["tgl"] = "tl",
            ["hi"] = "hi", ["hin"] = "hi",
            ["ar"] = "ar", ["ara"] = "ar",
            ["tr"] = "tr", ["tur"] = "tr",
            ["ru"] = "ru", ["rus"] = "ru",
            ["es"] = "es", ["spa"] = "es",
            ["pt"] = "pt", ["por"] = "pt", ["pt-br"] = "pt", ["pob"] = "pt",
            ["fr"] = "fr", ["fra"] = "fr", ["fre"] = "fr",
            ["de"] = "de", ["deu"] = "de", ["ger"] = "de",
            ["it"] = "it", ["ita"] = "it",
            ["nl"] = "nl", ["nld"] = "nl", ["dut"] = "nl",
            ["pl"] = "pl", ["pol"] = "pl",
        };

        private static readonly HashSet<string> Chinese = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "zh", "chi", "zho" };

        /// <summary>Mã site cho một trong các mã ngôn ngữ (lấy mã đầu tiên khớp), null nếu site không hỗ trợ.</summary>
        public static string ToSite(IEnumerable<string> codes, string chineseVariant = "zh-cn")
        {
            var list = codes.Where(c => !string.IsNullOrWhiteSpace(c)).Select(c => c.Trim()).ToList();
            foreach (var c in list)
            {
                if (Map.TryGetValue(c, out var site))
                    return site;
            }
            return list.Any(Chinese.Contains) ? (chineseVariant == "zh-tw" ? "zh-tw" : "zh-cn") : null;
        }

        public static string ToSite(string code, string chineseVariant = "zh-cn") => ToSite(new[] { code }, chineseVariant);

        public static string DisplayName(string site)
        {
            switch (site)
            {
                case "vi": return "Vietnamese";
                case "en": return "English";
                case "id": return "Indonesian";
                case "ms": return "Malay";
                case "th": return "Thai";
                case "zh-cn": return "Chinese (Simplified)";
                case "zh-tw": return "Chinese (Traditional)";
                case "ko": return "Korean";
                case "ja": return "Japanese";
                case "tl": return "Filipino";
                case "hi": return "Hindi";
                case "ar": return "Arabic";
                case "tr": return "Turkish";
                case "ru": return "Russian";
                case "es": return "Spanish";
                case "pt": return "Portuguese";
                case "fr": return "French";
                case "de": return "German";
                case "it": return "Italian";
                case "nl": return "Dutch";
                case "pl": return "Polish";
                default: return site;
            }
        }
    }
}
