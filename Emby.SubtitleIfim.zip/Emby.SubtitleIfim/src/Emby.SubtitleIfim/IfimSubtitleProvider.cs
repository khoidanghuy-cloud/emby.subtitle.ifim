using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Entities.TV;
using MediaBrowser.Controller.Library;
using MediaBrowser.Controller.MediaEncoding;
using MediaBrowser.Controller.Providers;
using MediaBrowser.Controller.Subtitles;
using MediaBrowser.Model.Dlna;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Logging;
using MediaBrowser.Model.MediaInfo;
using MediaBrowser.Model.Providers;
using MediaBrowser.Model.Serialization;

namespace Emby.SubtitleIfim
{
    /// <summary>
    /// Nguồn phụ đề "subtitle.ifim": lấy một phụ đề dạng chữ sẵn có của phim (file .srt/.ass đi kèm hoặc track nhúng),
    /// gửi lên subtitle.ifim.shop dịch sang ngôn ngữ Emby đang tìm, rồi trả bản dịch cho Emby lưu cạnh file phim.
    /// Emby tự gọi provider này khi quét thư viện / chạy tác vụ "Download missing subtitles", hoặc khi bấm Search.
    /// </summary>
    public class IfimSubtitleProvider : ISubtitleProvider
    {
        private const int MaxResults = 3;

        // Mỗi lần chỉ dịch 1 file => quét cả thư viện không làm server quá tải
        private static readonly SemaphoreSlim TranslateLock = new SemaphoreSlim(1, 1);

        private readonly ILibraryManager _libraryManager;
        private readonly IMediaSourceManager _mediaSourceManager;
        private readonly ISubtitleEncoder _subtitleEncoder;
        private readonly ILogger _logger;
        private readonly IfimApiClient _api;

        public IfimSubtitleProvider(ILibraryManager libraryManager, IMediaSourceManager mediaSourceManager,
            ISubtitleEncoder subtitleEncoder, IJsonSerializer json, ILogManager logManager)
        {
            _libraryManager = libraryManager;
            _mediaSourceManager = mediaSourceManager;
            _subtitleEncoder = subtitleEncoder;
            _logger = logManager.GetLogger("subtitle.ifim");
            _api = new IfimApiClient(json, _logger);
        }

        public string Name => "subtitle.ifim";

        public IEnumerable<VideoContentType> SupportedMediaTypes => new[] { VideoContentType.Movie, VideoContentType.Episode };

        private static PluginConfiguration Config => Plugin.Instance.Configuration;

        public Task<IEnumerable<RemoteSubtitleInfo>> Search(SubtitleSearchRequest request, CancellationToken cancellationToken)
        {
            IEnumerable<RemoteSubtitleInfo> results = Array.Empty<RemoteSubtitleInfo>();
            var config = Config;
            if (string.IsNullOrWhiteSpace(config.ApiKey) || string.IsNullOrEmpty(request.MediaPath))
                return Task.FromResult(results);

            var target = Languages.ToSite(RequestLanguageCodes(request), config.ChineseVariant);
            if (target == null)
                return Task.FromResult(results);

            var item = _libraryManager.FindByPath(request.MediaPath, false);
            if (item == null)
                return Task.FromResult(results);

            var lang3 = request.LanguageInfo?.ThreeLetterISOLanguageName ?? request.Language;
            results = SourceStreams(item, target, config)
                .Take(MaxResults)
                .Select(s => new RemoteSubtitleInfo
                {
                    Id = $"{item.InternalId}_{s.Index}_{target}_{lang3}",
                    ProviderName = Name,
                    Name = $"{Path.GetFileNameWithoutExtension(item.Path)} ({SourceLabel(s)} → {Languages.DisplayName(target)}, AI)",
                    Format = "srt",
                    Language = lang3,
                    Author = "subtitle.ifim.shop",
                    Comment = $"Machine-translated from the {SourceLabel(s)} subtitle of this video" +
                              (config.Bilingual ? " (bilingual)" : ""),
                    // Thời gian khớp tuyệt đối, nhưng KHÔNG báo IsHashMatch: cờ đó nghĩa là "phụ đề làm cho đúng file này",
                    // báo true sẽ khiến bản dịch máy vượt bộ lọc "perfect match" và lấn phụ đề người dịch.
                    IsHashMatch = false,
                    IsForced = s.IsForced,
                    IsHearingImpaired = s.IsHearingImpaired
                })
                .ToList();
            return Task.FromResult(results);
        }

        public async Task<SubtitleResponse> GetSubtitles(string id, CancellationToken cancellationToken)
        {
            var parts = id.Split('_');
            if (parts.Length != 4 || !long.TryParse(parts[0], out var itemId) || !int.TryParse(parts[1], out var streamIndex))
                throw new ArgumentException("Invalid subtitle id: " + id);
            var target = parts[2];
            var lang3 = parts[3];

            var item = _libraryManager.GetItemById(itemId) ?? throw new FileNotFoundException("Item not found: " + itemId);
            var stream = _mediaSourceManager.GetMediaStreams(item)
                             .FirstOrDefault(s => s.Type == MediaStreamType.Subtitle && s.Index == streamIndex)
                         ?? throw new FileNotFoundException($"Subtitle stream {streamIndex} not found for {item.Path}");

            var srt = await ReadAsSrt(item, stream, cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(srt) || srt.IndexOf("-->", StringComparison.Ordinal) < 0)
                throw new InvalidDataException("Source subtitle is empty: " + (stream.Path ?? item.Path));

            string translated;
            await TranslateLock.WaitAsync(cancellationToken).ConfigureAwait(false);
            try
            {
                translated = await _api.TranslateAsync(Config, srt, Path.GetFileNameWithoutExtension(item.Path) + ".srt",
                    target, Title(item), cancellationToken).ConfigureAwait(false);
            }
            finally
            {
                TranslateLock.Release();
            }

            return new SubtitleResponse
            {
                Format = "srt",
                Language = lang3,
                IsForced = stream.IsForced,
                IsHearingImpaired = stream.IsHearingImpaired,
                Stream = new MemoryStream(new UTF8Encoding(false).GetBytes(translated))
            };
        }

        private static IEnumerable<string> RequestLanguageCodes(SubtitleSearchRequest request)
        {
            var info = request.LanguageInfo;
            // zh-TW / zh-CN (2 chữ) trước để phân biệt phồn thể / giản thể
            if (info?.TwoLetterISOLanguageNames != null)
                foreach (var c in info.TwoLetterISOLanguageNames) yield return c;
            if (info?.TwoLetterISOLanguageName != null) yield return info.TwoLetterISOLanguageName;
            yield return request.Language;
            if (info?.ThreeLetterISOLanguageNames != null)
                foreach (var c in info.ThreeLetterISOLanguageNames) yield return c;
        }

        /// <summary>Các phụ đề dạng chữ có thể đem dịch, tốt nhất trước. Bỏ qua phụ đề đã cùng ngôn ngữ đích.</summary>
        private IEnumerable<MediaStream> SourceStreams(BaseItem item, string target, PluginConfiguration config)
        {
            var preferred = Languages.ToSite(config.SourceLanguage ?? "eng");
            return _mediaSourceManager.GetMediaStreams(item)
                .Where(s => s.Type == MediaStreamType.Subtitle && s.IsTextSubtitleStream && !s.IsClosedCaptions)
                .Where(s => Languages.ToSite(s.Language ?? "", config.ChineseVariant) != target)
                .OrderByDescending(s => preferred != null && Languages.ToSite(s.Language ?? "") == preferred)
                .ThenBy(s => s.IsForced)               // phụ đề forced chỉ có vài câu
                .ThenBy(s => s.IsHearingImpaired)      // SDH có thêm [tiếng động] => dịch tốn hơn
                .ThenByDescending(s => !string.IsNullOrEmpty(s.Language))
                .ThenBy(s => s.Index);
        }

        private static string SourceLabel(MediaStream s)
        {
            var lang = Languages.ToSite(s.Language ?? "");
            var name = lang != null ? Languages.DisplayName(lang) : (s.DisplayLanguage ?? s.Language ?? "unknown language");
            return name + (s.IsExternal ? "" : " embedded") + (s.IsForced ? " forced" : "") + (s.IsHearingImpaired ? " SDH" : "");
        }

        private static string Title(BaseItem item)
        {
            if (item is Episode ep && !string.IsNullOrEmpty(ep.SeriesName))
                return $"{ep.SeriesName} S{ep.ParentIndexNumber ?? 0:00}E{ep.IndexNumber ?? 0:00}";
            return item.ProductionYear.HasValue ? $"{item.Name} ({item.ProductionYear})" : item.Name;
        }

        /// <summary>Phụ đề nguồn dưới dạng SRT. Emby chuyển ASS/VTT/track nhúng sang SRT và trả về
        /// <b>đường dẫn</b> file kết quả (không phải nội dung) => đọc file đó, nhận đúng bảng mã.</summary>
        private async Task<string> ReadAsSrt(BaseItem item, MediaStream stream, CancellationToken cancellationToken)
        {
            var externalSrt = stream.IsExternal && IsSrt(stream.Path) && File.Exists(stream.Path);
            if (externalSrt && TryReadUtf8(stream.Path, out var utf8))
                return utf8;

            // ASS/VTT/track nhúng, hoặc .srt bảng mã cũ (Windows-1252, GBK, Big5...): để Emby chuyển sang SRT UTF-8,
            // vì Emby tự nhận bảng mã. Encoding.GetEncoding("gbk") trong plugin cần đăng ký CodePagesEncodingProvider.
            string result;
            try
            {
                result = await _subtitleEncoder.GetSubtitles(item.Path, Protocol(item.Path),
                    false, null, stream, "srt", 0, 0, false, EncodingContext.Static, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex) when (externalSrt && !cancellationToken.IsCancellationRequested)
            {
                _logger.ErrorException("subtitle.ifim: Emby could not convert {0}, reading it directly", ex, stream.Path);
                return await ReadText(stream.Path, stream, cancellationToken).ConfigureAwait(false);
            }
            if (!string.IsNullOrEmpty(result) && result.IndexOf("-->", StringComparison.Ordinal) < 0 && File.Exists(result.Trim()))
                return await ReadText(result.Trim(), stream, cancellationToken).ConfigureAwait(false);
            return result;
        }

        private static bool TryReadUtf8(string path, out string text)
        {
            try
            {
                text = new UTF8Encoding(false, true).GetString(File.ReadAllBytes(path)).TrimStart('﻿');
                return true;
            }
            catch (DecoderFallbackException)
            {
                text = null;
                return false;
            }
        }

        private async Task<string> ReadText(string path, MediaStream stream, CancellationToken cancellationToken)
        {
            if (TryReadUtf8(path, out var utf8))
                return utf8;
            var bytes = File.ReadAllBytes(path);
            // Không phải UTF-8 (phụ đề cũ: Windows-1252, GBK, Big5...) => hỏi Emby bảng mã
            try
            {
                var charset = await _subtitleEncoder.GetSubtitleFileCharacterSet(path, null, MediaProtocol.File, null,
                    cancellationToken).ConfigureAwait(false);
                if (!string.IsNullOrEmpty(charset))
                    return Encoding.GetEncoding(charset).GetString(bytes);
            }
            catch (Exception ex)
            {
                _logger.ErrorException("subtitle.ifim: cannot decode the character set of {0}", ex, path);
            }
            return Encoding.GetEncoding("ISO-8859-1").GetString(bytes);
        }

        private static MediaProtocol Protocol(string path) =>
            path.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || path.StartsWith("https://", StringComparison.OrdinalIgnoreCase)
                ? MediaProtocol.Http : MediaProtocol.File;

        private static bool IsSrt(string path) => path != null && path.EndsWith(".srt", StringComparison.OrdinalIgnoreCase);

    }
}
