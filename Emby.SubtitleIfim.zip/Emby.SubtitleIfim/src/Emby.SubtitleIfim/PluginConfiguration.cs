using MediaBrowser.Model.Plugins;

namespace Emby.SubtitleIfim
{
    public class PluginConfiguration : BasePluginConfiguration
    {
        /// <summary>Key tạo ở https://subtitle.ifim.shop/account/api</summary>
        public string ApiKey { get; set; } = "";

        public string ServerUrl { get; set; } = "https://subtitle.ifim.shop";

        /// <summary>Ngôn ngữ phụ đề nguồn ưu tiên (mã ISO 639-2, vd. eng).</summary>
        public string SourceLanguage { get; set; } = "eng";

        /// <summary>Giữ dòng gốc, thêm bản dịch bên dưới.</summary>
        public bool Bilingual { get; set; }

        /// <summary>google (Standard) hoặc expert (Expert Translation, dùng lượt / iDollar của tài khoản).</summary>
        public string Engine { get; set; } = "google";

        /// <summary>Chinese không rõ giản thể / phồn thể thì dịch sang: zh-cn hoặc zh-tw.</summary>
        public string ChineseVariant { get; set; } = "zh-cn";

        public int TimeoutMinutes { get; set; } = 20;
    }
}
